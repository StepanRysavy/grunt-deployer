/*! 
 *  by  (@) 
 * v1.0.0 from 2015-08-19 
*/

!function(a){"use strict";function b(){}function c(){}a=a||{},a.app=new b,a.data=new c,a.data.cache=1*new Date}(window),function(a,b,c){"use strict";var d=new FT,e=FT.query("#container");d.applyClickTag(e,1)}(window,window.app,window.data);